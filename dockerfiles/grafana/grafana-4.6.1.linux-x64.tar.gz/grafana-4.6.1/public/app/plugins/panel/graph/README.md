# Graph Panel -  Native Plugin

The Graph is the main graph panel and is **included** with Grafana. It provides a very rich set of graphing options.

Read more about it here:

[http://docs.grafana.org/reference/graph/](http://docs.grafana.org/reference/graph/)