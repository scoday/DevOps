declare var System: any;

declare module 'eventemitter3' {
  var config: any;
  export default config;
}
